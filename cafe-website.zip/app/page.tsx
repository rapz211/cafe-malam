import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { MapPin, Clock, Phone, Instagram, Facebook, Mail } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-50 border-b">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-primary">
            Café Delight
          </Link>
          <div className="hidden md:flex gap-6">
            <Link href="#home" className="hover:text-primary transition-colors">
              Home
            </Link>
            <Link href="#menu" className="hover:text-primary transition-colors">
              Menu
            </Link>
            <Link href="#gallery" className="hover:text-primary transition-colors">
              Gallery
            </Link>
            <Link href="#contact" className="hover:text-primary transition-colors">
              Contact
            </Link>
          </div>
          <Button asChild className="hidden md:inline-flex">
            <Link href="#contact">Order Now</Link>
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="pt-16 min-h-screen flex items-center bg-gradient-to-br from-background to-muted">
        <div className="container mx-auto px-4 py-20">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-5xl md:text-6xl font-bold text-balance leading-tight">
                Welcome to <span className="text-primary">Café Delight</span>
              </h1>
              <p className="text-xl text-muted-foreground text-pretty leading-relaxed">
                Experience the perfect blend of artisan coffee, delicious food, and warm ambiance. Your cozy corner in
                the heart of the city.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button asChild size="lg">
                  <Link href="#menu">View Menu</Link>
                </Button>
                <Button asChild size="lg" variant="outline">
                  <Link href="#contact">Visit Us</Link>
                </Button>
              </div>
            </div>
            <div className="relative h-[500px] rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://placehold.co/800x1000?text=Cozy+cafe+interior+with+warm+lighting+wooden+tables+and+comfortable+seating+area+with+coffee+bar+in+background"
                alt="Cozy cafe interior with warm lighting, wooden tables and comfortable seating area with coffee bar in background"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="pt-6">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Open Daily</h3>
                <p className="text-muted-foreground">
                  Monday - Friday: 7:00 AM - 10:00 PM
                  <br />
                  Saturday - Sunday: 8:00 AM - 11:00 PM
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <MapPin className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Prime Location</h3>
                <p className="text-muted-foreground">
                  Easy to find, easy to reach. Perfect spot for meetings, work, or relaxation.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <Phone className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Order Ahead</h3>
                <p className="text-muted-foreground">
                  Call us to pre-order your favorites and skip the wait. We'll have it ready!
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Menu Section */}
      <section id="menu" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Our Menu</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">Crafted with passion, served with love</p>
          </div>

          {/* Coffee & Beverages */}
          <div className="mb-16">
            <h3 className="text-3xl font-bold mb-8 text-center">☕ Coffee & Beverages</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { name: "Espresso", price: "Rp 20.000", desc: "Rich and bold single shot" },
                { name: "Cappuccino", price: "Rp 28.000", desc: "Classic espresso with steamed milk foam" },
                { name: "Café Latte", price: "Rp 30.000", desc: "Smooth espresso with creamy milk" },
                { name: "Americano", price: "Rp 22.000", desc: "Espresso with hot water" },
                { name: "Caramel Macchiato", price: "Rp 35.000", desc: "Vanilla and caramel perfection" },
                { name: "Iced Coffee", price: "Rp 25.000", desc: "Refreshing cold brew" },
                { name: "Matcha Latte", price: "Rp 32.000", desc: "Premium Japanese green tea" },
                { name: "Chocolate", price: "Rp 28.000", desc: "Rich hot chocolate" },
                { name: "Fresh Juice", price: "Rp 25.000", desc: "Orange, apple, or mixed berries" },
              ].map((item, idx) => (
                <Card key={idx} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-semibold text-lg">{item.name}</h4>
                      <span className="text-primary font-bold">{item.price}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Food */}
          <div className="mb-16">
            <h3 className="text-3xl font-bold mb-8 text-center">🍽️ Food</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { name: "Croissant", price: "Rp 22.000", desc: "Buttery and flaky French pastry" },
                { name: "Club Sandwich", price: "Rp 45.000", desc: "Triple-decker with chicken & bacon" },
                { name: "Caesar Salad", price: "Rp 38.000", desc: "Crisp romaine with parmesan" },
                { name: "Pasta Carbonara", price: "Rp 48.000", desc: "Creamy Italian classic" },
                { name: "Nasi Goreng", price: "Rp 35.000", desc: "Indonesian fried rice special" },
                { name: "Avocado Toast", price: "Rp 32.000", desc: "Smashed avocado on sourdough" },
                { name: "Chicken Burger", price: "Rp 42.000", desc: "Grilled chicken with special sauce" },
                { name: "Beef Steak", price: "Rp 75.000", desc: "Tender beef with mushroom sauce" },
                { name: "Pizza Margherita", price: "Rp 55.000", desc: "Classic tomato, mozzarella & basil" },
              ].map((item, idx) => (
                <Card key={idx} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-semibold text-lg">{item.name}</h4>
                      <span className="text-primary font-bold">{item.price}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Desserts */}
          <div>
            <h3 className="text-3xl font-bold mb-8 text-center">🍰 Desserts</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { name: "Tiramisu", price: "Rp 35.000", desc: "Classic Italian coffee-flavored dessert" },
                { name: "Cheesecake", price: "Rp 38.000", desc: "New York style with berry sauce" },
                { name: "Chocolate Lava Cake", price: "Rp 40.000", desc: "Warm molten chocolate center" },
                { name: "Brownies", price: "Rp 25.000", desc: "Fudgy chocolate brownies" },
                { name: "Apple Pie", price: "Rp 32.000", desc: "Homemade with vanilla ice cream" },
                { name: "Panna Cotta", price: "Rp 30.000", desc: "Silky Italian custard" },
              ].map((item, idx) => (
                <Card key={idx} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-semibold text-lg">{item.name}</h4>
                      <span className="text-primary font-bold">{item.price}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section id="gallery" className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Gallery</h2>
            <p className="text-xl text-muted-foreground">A glimpse into our world</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <div className="relative h-64 rounded-lg overflow-hidden">
              <img
                src="https://placehold.co/400x500?text=Barista+making+latte+art+pouring+milk+creating+beautiful+heart+pattern+in+white+ceramic+cup"
                alt="Barista making latte art pouring milk creating beautiful heart pattern in white ceramic cup"
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
              />
            </div>
            <div className="relative h-64 rounded-lg overflow-hidden">
              <img
                src="https://placehold.co/400x500?text=Fresh+croissants+and+pastries+displayed+on+wooden+board+with+golden+brown+crust"
                alt="Fresh croissants and pastries displayed on wooden board with golden brown crust"
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
              />
            </div>
            <div className="relative h-64 rounded-lg overflow-hidden">
              <img
                src="https://placehold.co/400x500?text=Cappuccino+with+perfect+foam+art+on+marble+table+with+sunlight"
                alt="Cappuccino with perfect foam art on marble table with sunlight"
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
              />
            </div>
            <div className="relative h-64 rounded-lg overflow-hidden">
              <img
                src="https://placehold.co/400x500?text=Cozy+reading+corner+with+vintage+leather+chairs+and+bookshelf+in+warm+ambient+lighting"
                alt="Cozy reading corner with vintage leather chairs and bookshelf in warm ambient lighting"
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
              />
            </div>
            <div className="relative h-64 rounded-lg overflow-hidden">
              <img
                src="https://placehold.co/400x500?text=Colorful+smoothie+bowls+with+fresh+fruits+and+granola+toppings+arranged+beautifully"
                alt="Colorful smoothie bowls with fresh fruits and granola toppings arranged beautifully"
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
              />
            </div>
            <div className="relative h-64 rounded-lg overflow-hidden">
              <img
                src="https://placehold.co/400x500?text=Outdoor+patio+seating+area+with+plants+and+string+lights+at+sunset"
                alt="Outdoor patio seating area with plants and string lights at sunset"
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
              />
            </div>
            <div className="relative h-64 rounded-lg overflow-hidden">
              <img
                src="https://placehold.co/400x500?text=Artisan+coffee+beans+in+burlap+sack+with+vintage+grinder+on+rustic+wooden+surface"
                alt="Artisan coffee beans in burlap sack with vintage grinder on rustic wooden surface"
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
              />
            </div>
            <div className="relative h-64 rounded-lg overflow-hidden">
              <img
                src="https://placehold.co/400x500?text=Chocolate+lava+cake+with+vanilla+ice+cream+and+berry+garnish+on+elegant+plate"
                alt="Chocolate lava cake with vanilla ice cream and berry garnish on elegant plate"
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Visit Us</h2>
            <p className="text-xl text-muted-foreground">We'd love to see you!</p>
          </div>
          <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            <div className="space-y-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <MapPin className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-lg mb-2">Address</h3>
                      <p className="text-muted-foreground">
                        Jl. Contoh Alamat No. 123
                        <br />
                        Jakarta Selatan, DKI Jakarta 12345
                        <br />
                        Indonesia
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Clock className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-lg mb-2">Opening Hours</h3>
                      <p className="text-muted-foreground">
                        Monday - Friday: 7:00 AM - 10:00 PM
                        <br />
                        Saturday: 8:00 AM - 11:00 PM
                        <br />
                        Sunday: 8:00 AM - 11:00 PM
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Phone className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-lg mb-2">Contact</h3>
                      <p className="text-muted-foreground">
                        Phone: +62 812-3456-7890
                        <br />
                        Email: info@cafedelight.com
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="flex gap-4">
                <Button size="lg" variant="outline" className="flex-1 bg-transparent">
                  <Instagram className="h-5 w-5 mr-2" />
                  Instagram
                </Button>
                <Button size="lg" variant="outline" className="flex-1 bg-transparent">
                  <Facebook className="h-5 w-5 mr-2" />
                  Facebook
                </Button>
              </div>
            </div>

            <div className="relative h-[500px] rounded-2xl overflow-hidden shadow-xl">
              <img
                src="https://placehold.co/600x800?text=Google+Maps+location+pin+on+street+map+showing+cafe+location+in+urban+area"
                alt="Google Maps location pin on street map showing cafe location in urban area"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                <Button size="lg" asChild>
                  <a href="https://maps.app.goo.gl/MF89jDCFEi62tGeA6" target="_blank" rel="noopener noreferrer">
                    <MapPin className="h-5 w-5 mr-2" />
                    Open in Google Maps
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="text-2xl font-bold mb-4">Café Delight</h3>
              <p className="text-muted-foreground">
                Your daily dose of coffee and happiness. Crafted with passion, served with love.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <div className="space-y-2">
                <Link href="#home" className="block text-muted-foreground hover:text-primary">
                  Home
                </Link>
                <Link href="#menu" className="block text-muted-foreground hover:text-primary">
                  Menu
                </Link>
                <Link href="#gallery" className="block text-muted-foreground hover:text-primary">
                  Gallery
                </Link>
                <Link href="#contact" className="block text-muted-foreground hover:text-primary">
                  Contact
                </Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Follow Us</h4>
              <div className="flex gap-4">
                <Button size="icon" variant="outline">
                  <Instagram className="h-5 w-5" />
                </Button>
                <Button size="icon" variant="outline">
                  <Facebook className="h-5 w-5" />
                </Button>
                <Button size="icon" variant="outline">
                  <Mail className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t pt-8 text-center text-muted-foreground">
            <p>&copy; 2025 Café Delight. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
